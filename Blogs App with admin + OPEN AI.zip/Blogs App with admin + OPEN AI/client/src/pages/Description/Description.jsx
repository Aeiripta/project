/* eslint-disable no-undef */
/* eslint-disable no-unused-vars */
import React, { useState, useEffect, useRef } from "react";
import { useParams } from "react-router-dom";
import { useSelector } from "react-redux";
import { FaRegHeart, FaHeart } from "react-icons/fa";
import { FaVolumeUp, FaVolumeMute } from "react-icons/fa";
import axios from "axios";
import { toast } from "react-toastify";

const Description = () => {
  const [Data, setData] = useState(null); // Initialize data as null
  const [Favorites, setFavorites] = useState(false);
  const [TranslatorLoaded, setTranslatorLoaded] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const { id } = useParams();
  const backendLink = useSelector((state) => state.prod.link);
  const utteranceRef = useRef(null);

  // Initialize Google Translate widget
  useEffect(() => {
    const googleTranslateElementInit = () => {
      new window.google.translate.TranslateElement(
        { pageLanguage: "en" },
        "google_translate_element"
      );
      setTranslatorLoaded(true);
    };

    if (!window.google?.translate?.TranslateElement) {
      const script = document.createElement("script");
      script.src =
        "//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit";
      script.async = true;
      document.body.appendChild(script);
      script.onload = googleTranslateElementInit;
    } else {
      googleTranslateElementInit();
    }
  }, []);

  // Fetch blog details and favorites status
  useEffect(() => {
    const fetchBlogDetails = async () => {
      try {
        const res = await axios.get(`${backendLink}/api/v1/getDescById/${id}`, {
          withCredentials: true,
        });
        setFavorites(res.data.favourite);
        setData(res.data.blog);
      } catch (error) {
        toast.error("Failed to fetch blog details");
        console.error("Error fetching blog details:", error);
      }
    };
    fetchBlogDetails();
  }, [backendLink, id]);

  // Handle adding/removing favorite blogs
  const handleFavoriteToggle = async () => {
    try {
      const url = Favorites
        ? `${backendLink}/api/v1/removeBlogsFromFavourite/${id}`
        : `${backendLink}/api/v1/addBlogsToFavourite/${id}`;
      const res = await axios.put(url, {}, { withCredentials: true });
      toast.success(res.data.message);
      setFavorites(!Favorites);
    } catch (error) {
      toast.error("Failed to update favorites");
      console.error("Error updating favorites:", error);
    }
  };

  // Handle text-to-speech functionality
  const handleSpeak = () => {
    if (!Data?.description) return;

    if (isSpeaking) {
      window.speechSynthesis.cancel();
      setIsSpeaking(false);
    } else {
      const utterance = new SpeechSynthesisUtterance(Data.description);
      utterance.lang = "en-US";
      utterance.onend = () => setIsSpeaking(false);
      window.speechSynthesis.speak(utterance);
      utteranceRef.current = utterance;
      setIsSpeaking(true);
    }
  };

  // Stop speech when component unmounts
  useEffect(() => {
    return () => {
      window.speechSynthesis.cancel();
    };
  }, []);

  return (
    <div>
      {Data ? (
        <>
          <div className="w-full flex items-center justify-between">
            <h1 className="text-2xl font-semibold w-4/6">{Data.title}</h1>
            <div className="flex gap-4 w-2/6 justify-end text-2xl lg:text-3xl">
              <button onClick={handleFavoriteToggle}>
                {Favorites ? (
                  <FaHeart className="text-yellow-400 hover:cursor-pointer" />
                ) : (
                  <FaRegHeart className="hover:cursor-pointer" />
                )}
              </button>
              <button onClick={handleSpeak}>
                {isSpeaking ? (
                  <FaVolumeMute className="hover:cursor-pointer text-blue-500" />
                ) : (
                  <FaVolumeUp className="hover:cursor-pointer" />
                )}
              </button>
            </div>
          </div>
          <img
            className="mt-4 w-full h-[400px] object-cover rounded"
            src={`${Data.image}`}
            alt="blog-image"
          />
          <p className="mt-4">{Data.description}</p>
        </>
      ) : (
        <p className="text-gray-500 mt-4">Loading blog details...</p>
      )}

      {/* Google Translate Widget */}
      {TranslatorLoaded ? (
        <div
          id="google_translate_element"
          className="my-4 border border-black px-4 py-2 rounded"
        />
      ) : (
        <div className="my-4">
          Loading Translator... (May be a network issue)
        </div>
      )}
    </div>
  );
};

export default Description;
