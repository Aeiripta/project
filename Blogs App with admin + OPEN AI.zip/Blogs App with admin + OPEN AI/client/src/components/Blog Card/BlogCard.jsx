/* eslint-disable no-unused-vars */
/* eslint-disable react/prop-types */
import React from "react";
import { Link } from "react-router-dom";

const BlogCard = ({ items }) => {
  // Utility function to format the creation date
  const formatCreatedAt = (date) => {
    const now = new Date();
    const createdDate = new Date(date);
    const diffInMs = now - createdDate;
    const diffInMinutes = Math.floor(diffInMs / (1000 * 60));
    const diffInHours = Math.floor(diffInMinutes / 60);

    if (diffInMinutes < 60) {
      return `${diffInMinutes} min ago`;
    } else if (diffInHours < 24) {
      return `${diffInHours} hr ago`;
    } else {
      return ` on ${createdDate.toLocaleString()}`; // Exact date with time
    }
  };

  // Format the creation date (if available)
  const createdAt = items.createdAt ? formatCreatedAt(items.createdAt) : "N/A";

  // Retrieve the author (username) or fallback to "Unknown"
  const author = items.createdBy?.username || "we cam't show you that here !";
  // Retrieve the category title or fallback to "Uncategorized"
  const category = items.category?.title || "we cam't show you that here !";

  return (
    <div className="w-full rounded-md border-2 border-gray-300 p-4 mt-4 shadow-md flex-col lg:flex-row flex items-center justify-between gap-4">
      <div className="w-full lg:w-4/6">
        <img
          src={items.image}
          alt={items.title}
          className="rounded object-contain w-full h-[250px]"
        />
      </div>
      <div className="w-full lg:w-4/6">
        <h1
          className={`text-2xl font-semibold ${
            window.location.href.includes("/profile") && "mb-4"
          }`}
        >
          {items.title}
        </h1>
        {/* Display additional blog details */}
        <p className="text-sm text-gray-500 mb-2">
          By {author} <br/>
          {createdAt} <br/>
          Category: {category}
        </p>
        {!window.location.href.includes("/profile") && (
          <p className="mb-4">{items.description.slice(0, 150)}...</p>
        )}
        <Link
          to={`/description/${items._id}`}
          className="bg-blue-600 px-4 py-2 rounded text-white hover:bg-blue-700 transition-all duration-300"
        >
          Read Blog
        </Link>
      </div>
    </div>
  );
};

export default BlogCard;
