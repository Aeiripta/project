/* eslint-disable no-unused-vars */
import React from "react";
import AllBlogs from "../../../pages/All Blogs/page";
import { useDispatch, useSelector } from "react-redux";
const DashBoard = () => {
    const backendLink = useSelector((state) => state.prod.link);
    const theme = useSelector((state) => state.auth.theme);
    const dispatch = useDispatch();
  return (
    <div
      className={`${
        theme === "dark" && "bg-[#091018] text-slate-200"
      } m-4 py-4 px-8`}
    >
      <AllBlogs />
    </div>
  );
};

export default DashBoard;
