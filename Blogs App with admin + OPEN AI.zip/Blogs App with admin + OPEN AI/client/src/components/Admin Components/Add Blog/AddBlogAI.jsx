/* eslint-disable no-unused-vars */
import React, { useState, useEffect } from "react";
import axios from "axios";
import { toast } from "react-toastify";
import { useSelector } from "react-redux";

const AddBlogAI = () => {
  const backendLink = useSelector((state) => state.prod.link);
  const [titlePrompt, setTitlePrompt] = useState("");
  const [imagePrompt, setImagePrompt] = useState("");

  const [generatedTitle, setGeneratedTitle] = useState("");
  const [generatedBlog, setGeneratedBlog] = useState("");
  const [imageUrl, setImageUrl] = useState("");

  const [imageFile, setImageFile] = useState(null);
  const [categoryId, setCategoryId] = useState("");
  const [actualCategories, setActualCategories] = useState([]);

  const [loadingText, setLoadingText] = useState(false);
  const [loadingImage, setLoadingImage] = useState(false);
  const [loadingAdd, setLoadingAdd] = useState(false);

  useEffect(() => {
    const fetchCategories = async () => {
      try {
        const res = await axios.get(`${backendLink}/api/v1/getCategory`, {
          withCredentials: true,
        });
        setActualCategories(res.data.categories);
      } catch (err) {
        toast.error("Failed to fetch categories");
      }
    };
    fetchCategories();
  }, [backendLink]);

  const generateBlog = async () => {
    try {
      setLoadingText(true);
      const res = await axios.post(
        `${backendLink}/api/v1/generate-blog`,
        { prompt: titlePrompt },
        { withCredentials: true }
      );
      setGeneratedTitle(titlePrompt);
      setGeneratedBlog(res.data.blogContent);
      toast.success("Blog content generated!");
    } catch (err) {
      toast.error("Failed to generate blog content");
    } finally {
      setLoadingText(false);
    }
  };

  const generateImage = async () => {
    try {
      setLoadingImage(true);
      const res = await axios.post(
        `${backendLink}/api/v1/generate-image`,
        { prompt: imagePrompt },
        { withCredentials: true }
      );
      setImageUrl(res.data.imageUrl);
      toast.success("Image generated!");
    } catch (err) {
      toast.error("Failed to generate image");
    } finally {
      setLoadingImage(false);
    }
  };

  const handleAddBlog = async (e) => {
    e.preventDefault();
    try {
      setLoadingAdd(true);
      const form = new FormData();
      form.append("title", generatedTitle);
      form.append("description", generatedBlog);
      form.append("category", categoryId);

      if (imageFile) {
        form.append("image", imageFile);
      }

      const res = await axios.post(`${backendLink}/api/v1/addBlog`, form, {
        withCredentials: true,
      });
      toast.success(res.data.message);
      // Reset form
      setGeneratedBlog("");
      setGeneratedTitle("");
      setCategoryId("");
      setImageFile(null);
      setImageUrl("");
      setTitlePrompt("");
      setImagePrompt("");
    } catch (err) {
      toast.error(err?.response?.data?.error || "Failed to add blog");
    } finally {
      setLoadingAdd(false);
    }
  };

  return (
    <div className="bg-white p-6 rounded shadow space-y-6 py-[100px]">
      <h1 className="text-2xl font-semibold mb-4 mt-10">
        Generate Blog with AI
      </h1>

      {/* Blog Generation */}
      <div>
        <label className="block text-lg font-medium mb-2">
          Blog Title Prompt
        </label>
        <input
          type="text"
          className="w-full border rounded px-4 py-2 text-gray-800"
          placeholder="Enter your blog title or idea..."
          value={titlePrompt}
          onChange={(e) => setTitlePrompt(e.target.value)}
        />
        <button
          onClick={generateBlog}
          disabled={loadingText}
          className="mt-4 bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700"
        >
          {loadingText ? "Generating Blog..." : "Generate Blog"}
        </button>
        {generatedBlog && (
          <div className="mt-6 bg-gray-100 p-4 rounded">
            <h2 className="text-xl font-semibold mb-2 text-gray-800">
              Generated Blog:
            </h2>
            <p className="whitespace-pre-line text-gray-800">{generatedBlog}</p>
          </div>
        )}
      </div>

      {/* Image Generation */}
      {/*<div>
        <label className="block text-lg font-medium mb-2">Image Prompt</label>
        <input
          type="text"
          className="w-full border rounded px-4 py-2"
          placeholder="Describe the image you want..."
          value={imagePrompt}
          onChange={(e) => setImagePrompt(e.target.value)}
        />
        <button
          onClick={generateImage}
          disabled={loadingImage}
          className="mt-4 bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700"
        >
          {loadingImage ? "Generating Image..." : "Generate Image"}
        </button>
        {imageUrl && (
          <div className="mt-6">
            <h2 className="text-xl font-semibold mb-2">Generated Image:</h2>
            <img
              src={imageUrl}
              alt="Generated by AI"
              className="rounded shadow-lg max-w-full h-auto"
            />
          </div>
        )}
      </div> */}

      {/* Upload Image, Select Category, and Submit */}
      <form
        onSubmit={handleAddBlog}
        className="flex flex-col gap-4 mt-4 border-t pt-4"
      >
        <h2 className="text-xl font-semibold">Finalize Blog</h2>

        <input
          type="file"
          accept=".jpeg, .jpg, .png"
          className="border p-2 rounded"
          onChange={(e) => setImageFile(e.target.files[0])}
        />

        <select
          value={categoryId}
          onChange={(e) => setCategoryId(e.target.value)}
          className="px-4 py-2 rounded border text-gray-800"
          required
        >
          <option value="">Select Category</option>
          {actualCategories.map((item, i) => (
            <option value={item.title} key={i}>
              {item.title}
            </option>
          ))}
        </select>

        <button
          disabled={loadingAdd}
          className="bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700"
        >
          {loadingAdd ? "Adding Blog..." : "Add Blog"}
        </button>
      </form>
    </div>
  );
};

export default AddBlogAI;
