/* eslint-disable no-unused-vars */
import React, { useState } from "react";
import AddBlogManual from "./AddBlogManual";
import AddBlogAI from "./AddBlogAI";

const AddBlogTabs = () => {
  const [activeTab, setActiveTab] = useState("manual");

  return (
    <div className="p-4">
      <div className="flex gap-4 mb-6">
        <button
          className={`px-4 py-2 rounded ${
            activeTab === "manual" ? "bg-blue-600 text-white" : "bg-gray-400"
          }`}
          onClick={() => setActiveTab("manual")}
        >
          Add Blog Manually
        </button>
        <button
          className={`px-4 py-2 rounded ${
            activeTab === "ai" ? "bg-blue-600 text-white" : "bg-gray-400"
          }`}
          onClick={() => setActiveTab("ai")}
        >
          Add Blog with AI
        </button>
      </div>

      {activeTab === "manual" ? <AddBlogManual /> : <AddBlogAI />}
    </div>
  );
};

export default AddBlogTabs;
