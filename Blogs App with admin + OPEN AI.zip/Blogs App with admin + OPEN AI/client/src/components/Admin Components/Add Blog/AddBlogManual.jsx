/* eslint-disable no-unused-vars */
import React, { useEffect, useState } from "react";
import { useSelector } from "react-redux";
import axios from "axios";
import { toast } from "react-toastify";

const AddBlogManual = () => {
  const backendLink = useSelector((state) => state.prod.link);
  const [Title, setTitle] = useState("");
  const [Description, setDescription] = useState("");
  const [Image, setImage] = useState(null);
  const [Loading, setLoading] = useState(false);
  const [NewCategory, setNewCategory] = useState("");
  const [ActualCategories, setActualCategories] = useState([]);
  const [CategoryId, setCategoryId] = useState("");

  const handleAddBlog = async (e) => {
    e.preventDefault();
    try {
      setLoading(true);
      const form = new FormData();
      form.append("title", Title);
      form.append("description", Description);
      form.append("category", CategoryId);
      form.append("image", Image);
      const res = await axios.post(`${backendLink}/api/v1/addBlog`, form, {
        withCredentials: true,
      });
      alert("Blog added successfully");
      toast(
        `Blog added successfully by ${res.data.admin.username} (${res.data.admin.email})`
      );
    } catch (error) {
      //toast.error(error?.response?.data?.error || "Failed to add blog   or may be its a success check on dash board !");
      console.log(error);
      
    } finally {
      setTitle("");
      setDescription("");
      setImage(null);
      setCategoryId("");
      setLoading(false);
      
    }
  };

  const addCategoryHandle = async (e) => {
    e.preventDefault();
    const res = await axios.post(
      `${backendLink}/api/v1/addCategory`,
      { title: NewCategory },
      {
        withCredentials: true,
      }
    );
    toast.success(res.data.message);
    setNewCategory("");
  };

  useEffect(() => {
    const fetch = async () => {
      const res = await axios.get(`${backendLink}/api/v1/getCategory`, {
        withCredentials: true,
      });
      setActualCategories(res.data.categories);
    };
    fetch();
  }, [backendLink]);

  return (
    <div className="space-y-8 py-[100px]">
      <div className="bg-white p-4 rounded shadow">
        <h1 className="text-2xl font-semibold">Add Blog</h1>
        <form
          onSubmit={handleAddBlog}
          className="my-4 flex flex-col gap-4"
          encType="multipart/form-data"
        >
          <input
            type="text"
            placeholder="Title"
            className="outline-none p-4 bg-transparent text-3xl border-b border-zinc-400 font-semibold w-full"
            value={Title}
            onChange={(e) => setTitle(e.target.value)}
          />
          <textarea
            placeholder="Description"
            className="outline-none p-4 bg-transparent text-xl border-b border-zinc-400 font-semibold w-full"
            value={Description}
            onChange={(e) => setDescription(e.target.value)}
          />
          <div className="flex items-center justify-between gap-4">
            <input
              type="file"
              className="bg-zinc-900 rounded text-white"
              accept=".jpeg, .png, .jpg"
              onChange={(e) => setImage(e.target.files[0])}
            />
            <select
              className="px-4 py-2 rounded shadow text-gray-800"
              onChange={(e) => setCategoryId(e.target.value)}
              value={CategoryId}
            >
              <option value="">Select Category</option>
              {ActualCategories.map((item, i) => (
                <option value={item.title} key={i}>
                  {item.title}
                </option>
              ))}
            </select>
          </div>
          <div>
            {Loading ? (
              <div className="bg-blue-400 w-fit text-white rounded px-4 py-2 shadow-xl">
                Adding Blog...
              </div>
            ) : (
              <button className="bg-blue-600 text-white rounded px-4 py-2 shadow-xl hover:bg-blue-700 transition-all">
                Add Blog
              </button>
            )}
          </div>
        </form>
      </div>

      {/* Add Category */}
      <div className="bg-white p-4 rounded shadow">
        <h1 className="text-2xl font-semibold">Add New Category</h1>
        <form
          className="mt-4 flex items-center gap-4"
          onSubmit={addCategoryHandle}
        >
          <input
            type="text"
            placeholder="Your new category"
            className="border outline-none px-4 py-2 rounded bg-gray-50"
            required
            value={NewCategory}
            onChange={(e) => setNewCategory(e.target.value)}
          />
          <button className="bg-blue-600 px-4 py-2 rounded text-white">
            Add Category
          </button>
        </form>
      </div>
    </div>
  );
};

export default AddBlogManual;
