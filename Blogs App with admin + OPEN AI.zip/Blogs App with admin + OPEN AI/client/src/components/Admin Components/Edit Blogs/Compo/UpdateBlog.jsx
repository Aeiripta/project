/* eslint-disable no-unused-vars */
import React, { useState, useEffect } from "react";
import { useParams } from "react-router-dom";
import axios from "axios";
import { useSelector } from "react-redux";
import { toast } from "react-toastify";

const UpdateBlog = () => {
  const [Data, setData] = useState({ title: "", description: "" });
  const [Loading, setLoading] = useState(false);
  const { id } = useParams();
  const backendLink = useSelector((state) => state.prod.link);

  // Fetch blog data when component mounts or id changes
  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);
        const res = await axios.get(`${backendLink}/api/v1/getDescById/${id}`, {
          withCredentials: true,
        });
        if (res.data.blog) {
          setData(res.data.blog); // Populate form with fetched data
        } else {
          toast.error("Blog not found");
        }
      } catch (error) {
        toast.error("Failed to fetch blog details");
        console.error("Error fetching blog:", error);
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, [backendLink, id]);

  // Handle changes to form inputs
  const changeHandler = (e) => {
    const { name, value } = e.target;
    setData({ ...Data, [name]: value });
  };

  // Submit updated blog data
  const updateHandler = async (e) => {
    e.preventDefault();
    try {
      if (!Data.title || !Data.description) {
        toast.error("Please fill in all fields");
        return;
      }
      const res = await axios.put(
        `${backendLink}/api/v1/editBlog/${id}`,
        { title: Data.title, description: Data.description },
        {
          withCredentials: true,
        }
      );
      toast.success(res.data.message);
    } catch (error) {
      toast.error("Failed to update blog");
      console.error("Error updating blog:", error);
    }
  };

  return (
    <div className="p-4 h-screen">
      <h1 className="text-2xl font-semibold">Update Blog</h1>
      {Loading ? (
        <div className="mt-4 text-gray-500">Loading blog details...</div>
      ) : (
        Data && (
          <form onSubmit={updateHandler} className="my-4 flex flex-col gap-4">
            <input
              type="text"
              placeholder="Title"
              className="border-none outline-none p-4 bg-transparent text-3xl border-b border-zinc-400 font-semibold w-full text-gray-600"
              name="title"
              value={Data.title}
              onChange={changeHandler}
            />
            <textarea
              placeholder="Description"
              className="border-none outline-none p-4 bg-transparent text-xl border-b border-zinc-400 font-semibold w-full text-gray-600"
              name="description"
              value={Data.description}
              onChange={changeHandler}
            />
            <div>
              <button
                type="submit"
                className="bg-blue-600 text-white rounded px-4 py-2 shadow-xl hover:bg-blue-700 transition-all duration-300"
              >
                Update Blog
              </button>
            </div>
          </form>
        )
      )}
    </div>
  );
};

export default UpdateBlog;
