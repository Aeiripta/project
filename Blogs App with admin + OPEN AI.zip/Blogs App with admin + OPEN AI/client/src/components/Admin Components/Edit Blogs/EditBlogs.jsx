/* eslint-disable no-unused-vars */
import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { useSelector } from "react-redux";
import axios from "axios";
import { toast } from "react-toastify";

const EditBlogs = () => {
  const backendLink = useSelector((state) => state.prod.link);
  const [data, setData] = useState([]); // Ensuring state is initialized as an array
  const [isLoading, setIsLoading] = useState(false);

  // Fetch all blogs
  useEffect(() => {
    const fetchBlogs = async () => {
      try {
        setIsLoading(true);
        const res = await axios.get(`${backendLink}/api/v1/fetchAllBlogs`, {
          withCredentials: true,
        });
        setData(res.data.blogs || []); // Fallback to an empty array if no blogs found
      } catch (error) {
        toast.error("Failed to fetch blogs");
        console.error("Error fetching blogs:", error);
      } finally {
        setIsLoading(false);
      }
    };
    fetchBlogs();
  }, [backendLink]);

  // Delete a blog
  const deleteBlogHandler = async (id) => {
    try {
      const res = await axios.put(
        `${backendLink}/api/v1/deleteBlog/${id}`,
        {},
        {
          withCredentials: true,
        }
      );
      toast.success(res.data.message);
      // Update local data after deletion
      setData((prevData) => prevData.filter((blog) => blog._id !== id));
    } catch (error) {
      toast.error("Failed to delete blog");
      console.error("Error deleting blog:", error);
    }
  };

  return (
    <div className="p-4">
      <h1 className="text-2xl font-semibold">Edit Blogs</h1>
      {isLoading ? (
        <p className="text-gray-500 mt-4">Loading blogs...</p>
      ) : data.length > 0 ? (
        <div className="grid grid-cols-3 gap-8 lg:gap-4 my-4">
          {data.map((items, i) => (
            <div
              className="bg-white rounded-xl p-4 flex flex-col items-center justify-center shadow-xl"
              key={i}
            >
              <div className="w-full lg:w-4/6">
                <img
                  src={items.image}
                  alt={items.title}
                  className="rounded object-cover"
                />
              </div>
              <div className="mt-4">
                <h1 className="text-2xl font-semibold text-gray-800">
                  {items.title}
                </h1>
                <p className="mb-4 text-gray-800">
                  {items.description.slice(0, 170)}...
                </p>
              </div>
              <div className="w-[100%] flex items-center justify-between gap-4">
                <Link
                  to={`/admin-dashboard/update-blog/${items._id}`}
                  className="bg-blue-600 w-[100%] text-center text-white rounded px-4 py-2 hover:bg-blue-700"
                >
                  Edit
                </Link>
                <button
                  className="bg-red-600 w-[100%] text-white rounded px-4 py-2 hover:bg-red-700"
                  onClick={() => deleteBlogHandler(items._id)}
                >
                  Delete
                </button>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <p className="text-gray-500 mt-4">No blogs found.</p>
      )}
    </div>
  );
};

export default EditBlogs;
