/* eslint-disable no-unused-vars */
/* eslint-disable react/no-unescaped-entities */
import React from "react";
import { useNavigate } from "react-router-dom"; // Import useNavigate for navigation

const Footer = () => {
  const navigate = useNavigate(); // Initialize useNavigate

  return (
    <div className="py-6 px-5 w-full bg-black rounded-lg flex flex-col md:flex-row items-start justify-between gap-3 text-bold-black text-orange-600">
      {/* Left Column: Logo and Paragraph */}
      <div className="flex-1 flex flex-col items-start">
        <img
          src="/logo.png"
          alt="Blogger Logo"
          className="w-16 h-16 mb-2 rounded-full"
        />
        <p className="text-left text-sm md:text-base font-normal">
          Welcome to Blogger, a modern blogging platform designed to inspire
          creativity and provide an effortless experience for users. Whether
          you're a casual reader or a passionate writer, Blogger offers features
          that cater to every need. With its clean and intuitive design,
          combined with theme toggle support, users can enjoy browsing and
          creating blogs in a visually delightful environment.
        </p>
      </div>

      {/* Right Column: Links */}
      <div className="flex-1 flex flex-col space-y-2 items-center py-10">
        <a
          href="/contact"
          className="text-orange-600 hover:text-gray-200 transition text-sm md:text-base"
        >
          Contact Us
        </a>
        <a
          href="https://www.instagram.com/someshkumar7891/"
          target="_blank"
          rel="noopener noreferrer"
          className="text-orange-600 hover:text-gray-200 transition text-sm md:text-base"
        >
          Instagram
        </a>
        <a
          href="https://wa.me/"
          target="_blank"
          rel="noopener noreferrer"
          className="text-orange-600 hover:text-gray-200 transition text-sm md:text-base"
        >
          WhatsApp - 6372888211
        </a>

        <button
          onClick={() => navigate("/admin-login")} // Navigate to /admin-login on click
          className="w-[200px] bg-orange-500 text-white py-2 px-4 rounded-md hover:bg-orange-600 transition"
        >
          Go to Admin
        </button>
      </div>
    </div>
  );
};

export default Footer;
