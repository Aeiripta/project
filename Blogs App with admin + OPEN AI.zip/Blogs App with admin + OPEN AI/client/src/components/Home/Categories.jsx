import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { useSelector } from "react-redux";
import axios from "axios";

const Categories = () => {
  const backendLink = useSelector((state) => state.prod.link);
  const [cat, setCat] = useState();
  useEffect(() => {
    const fetch = async () => {
      const res = await axios.get(`${backendLink}/api/v1/getCategory`, {
        withCredentials: true,
      });
      //console.log(res.data);
      setCat(res.data.categories);
    };
    fetch();
  }, [backendLink]);

  return (
    <div className="mb-4 py-4">
      <h1 className="text-xl font-semibold mb-4 text-orange-600">Categories</h1>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {cat &&
          cat.map((items, i) => (
            <Link
              className={`px-4 text-black hover:shadow-2xl transition-all duration-300 py-2 text-center text-normal md:text-xl font-semibold bg-green-100 rounded`}
              key={i}
              to={`/cat/${items._id}`}
            >
              {items.title}
            </Link>
          ))}
      </div>
    </div>
  );
};

export default Categories;
