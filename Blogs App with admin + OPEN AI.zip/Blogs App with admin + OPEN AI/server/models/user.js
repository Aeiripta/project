const mongoose = require("mongoose");
const Schema = mongoose.Schema;

const userSchema = new Schema(
  {
    username: {
      type: String,
      required: true,
      unique: true,
    },
    email: {
      type: String,
      required: true,
      unique: true,
    },
    password: {
      type: String,
      required: true,
    },
    role: {
      type: String,
      required: true,
      default: "user",
      enum: ["user", "admin"],
    },
    avatar: {
      type: String,
    },
    favouriteBlogs: [{ type: Schema.Types.ObjectId, ref: "blog" }], // Stores blogs favorited by the user
    likedBlogs: [{ type: Schema.Types.ObjectId, ref: "blog" }], // Stores blogs liked by the user
    createdBlogs: [{ type: Schema.Types.ObjectId, ref: "blog" }], // Tracks blogs authored by the user
    bio: { type: String }, // Optional field for additional user info
    socialLinks: {
      twitter: { type: String },
      linkedin: { type: String },
    }, // Optional field for social media links
  },
  { timestamps: true }
);

module.exports = mongoose.model("user", userSchema);
