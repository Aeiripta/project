// const User = require("../models/user");
// const Blog = require("../models/blog");
// const bcrypt = require("bcryptjs");
// const jwt = require("jsonwebtoken");
// const Cat = require("../models/category");
// const axios = require("axios");
// const Replicate = require("replicate");

// const replicate = new Replicate({
//   auth: process.env.REPLICATE_API_TOKEN,
// });

// exports.adminLogin = async (req, res) => {
//   try {
//     const { email, password } = req.body;

//     if (!email || !password) {
//       return res
//         .status(400)
//         .json({ success: false, error: "All fields are required" });
//     }

//     //does the username or email exits
//     const existingUser = await User.findOne({ email });
//     if (!existingUser) {
//       return res
//         .status(400)
//         .json({ success: false, error: "Invalid credentials" });
//     }
//     if (existingUser.role !== "admin") {
//       return res
//         .status(400)
//         .json({ success: false, error: "Invalid credentials" });
//     }

//     const checkPass = await bcrypt.compare(password, existingUser.password);
//     if (!checkPass) {
//       return res
//         .status(400)
//         .json({ success: false, error: "Invalid credentials" });
//     }

//     const token = jwt.sign(
//       {
//         id: existingUser._id,
//         email: existingUser.email,
//       },
//       process.env.JWT_SECRET,
//       {
//         expiresIn: "30d", // Token expires in 30 days
//       }
//     );
//     res.cookie("blogsapptcm", token, {
//       httpOnly: true,
//       maxAge: 30 * 24 * 60 * 60 * 1000, // 30 days
//       secure: true,
//       sameSite: "None",
//     });
//     return res
//       .status(200)
//       .json({ success: true, message: "Login successfully" });
//   } catch (error) {
//     //console.log(error);
//     return res
//       .status(400)
//       .json({ success: false, error: "Internal server error" });
//   }
// };

// //create -blog

// exports.addBlog = async (req, res) => {
//   try {
//     const { title, description, category } = req.body;
//     if (!title || !description || !category) {
//       return res.status(400).json({ error: "All fields are required" });
//     }
//     if (!req.file) {
//       return res.status(400).json({ error: "Image is required" });
//     }
//     const existingCat = await Cat.findOne({ title: category });
//     if (!existingCat) {
//       return res.status(400).json({ error: "The category does not exist" });
//     }

//     const newBlog = new Blog({ title, description, image: req.file.path });
//     await newBlog.save();
//     existingCat.blogs.push(newBlog._id);
//     await existingCat.save();
//     return res.status(200).json({ success: true, message: "Blog Added" });
//   } catch (error) {
//     //console.log(error);
//     return res
//       .status(400)
//       .json({ success: false, error: "Internal server error" });
//   }
// };

// exports.genearteBlog = async (req, res) => {
//   const { prompt } = req.body;
//   try {
//     const response = await axios.post(
//       "https://openrouter.ai/api/v1/chat/completions",
//       {
//         model: "mistralai/mixtral-8x7b-instruct", // Free & powerful
//         messages: [
//           {
//             role: "user",
//             content: `Write a detailed blog on the topic: ${prompt}`,
//           },
//         ],
//       },
//       {
//         headers: {
//           Authorization: `Bearer ${process.env.OPENROUTER_API_KEY}`,
//           "Content-Type": "application/json",
//         },
//       }
//     );

//     const content = response.data.choices[0].message.content;
//     res.json({ blogContent: content });
//   } catch (err) {
//     console.log(err);
//     res.status(500).json({ error: "Failed to generate blog" });
//   }
// };

// // exports.generateImage = async (req, res) => {
// //   const { prompt } = req.body;

// //   try {
// //     const response = await axios.post(
// //       "https://api-inference.huggingface.co/models/stabilityai/stable-diffusion-2",
// //       {
// //         inputs: prompt,
// //       },
// //       {
// //         headers: {
// //           Authorization: `Bearer ${process.env.HF_TOKEN}`,
// //           Accept: "application/json",
// //         },
// //         responseType: "arraybuffer", // because image will come as binary
// //       }
// //     );

// //     // Convert binary image to base64
// //     const base64Image = Buffer.from(response.data, "binary").toString("base64");

// //     // Send base64 string to frontend
// //     res.status(200).json({
// //       image: `data:image/png;base64,${base64Image}`,
// //     });
// //   } catch (error) {
// //     console.error("Hugging Face error:", error.response?.data || error.message);
// //     res.status(500).json({
// //       error: "Failed to generate image. Try a different prompt or wait.",
// //     });
// //   }
// // };
const User = require("../models/user");
const Blog = require("../models/blog");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const Cat = require("../models/category");
const axios = require("axios");
const Replicate = require("replicate");

const replicate = new Replicate({
  auth: process.env.REPLICATE_API_TOKEN,
});

// Admin login functionality
exports.adminLogin = async (req, res) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res
        .status(400)
        .json({ success: false, error: "All fields are required" });
    }

    // Check if the user exists
    const existingUser = await User.findOne({ email });
    if (!existingUser || existingUser.role !== "admin") {
      return res
        .status(400)
        .json({ success: false, error: "Invalid credentials" });
    }

    // Verify the password
    const checkPass = await bcrypt.compare(password, existingUser.password);
    if (!checkPass) {
      return res
        .status(400)
        .json({ success: false, error: "Invalid credentials" });
    }

    // Generate a token
    const token = jwt.sign(
      {
        id: existingUser._id,
        email: existingUser.email,
      },
      process.env.JWT_SECRET,
      { expiresIn: "30d" }
    );

    res.cookie("blogsapptcm", token, {
      httpOnly: true,
      maxAge: 30 * 24 * 60 * 60 * 1000, // 30 days
      secure: true,
      sameSite: "None",
    });

    return res
      .status(200)
      .json({ success: true, message: "Login successfully" });
  } catch (error) {
    return res
      .status(500)
      .json({ success: false, error: "Internal server error" });
  }
};

// Add a new blog
exports.addBlog = async (req, res) => {
  try {
    const { title, description, category } = req.body;

    if (!title || !description || !category) {
      return res.status(400).json({ error: "All fields are required" });
    }
    if (!req.file) {
      return res.status(400).json({ error: "Image is required" });
    }

    // Verify the category exists
    const existingCat = await Cat.findOne({ title: category });
    if (!existingCat) {
      return res.status(400).json({ error: "The category does not exist" });
    }

    // Create a new blog
    const newBlog = new Blog({
      title,
      description,
      image: req.file.path,
      category: existingCat._id,
      createdBy: req.user._id, // Assuming `req.user` is populated by authentication middleware
    });

    await newBlog.save();

    // Update the category with the new blog
    existingCat.blogs.push(newBlog._id);
    await existingCat.save();

    // Add the blog to the user's created blogs
    const user = await User.findById(req.user._id);
    user.createdBlogs.push(newBlog._id);
    await user.save();

    return res
      .status(200)
      .json({ success: true, message: "Blog added successfully" });
  } catch (error) {
    console.error(error);
    return res
      .status(500)
      .json({ success: false, error: "Internal server error" });
  }
};

// Generate blog content using OpenRouter
exports.genearteBlog = async (req, res) => {
  const { prompt } = req.body;
  try {
    const response = await axios.post(
      "https://openrouter.ai/api/v1/chat/completions",
      {
        model: "mistralai/mixtral-8x7b-instruct", // Free & powerful
        messages: [
          {
            role: "user",
            content: `Write a detailed blog on the topic: ${prompt}`,
          },
        ],
      },
      {
        headers: {
          Authorization: `Bearer ${process.env.OPENROUTER_API_KEY}`,
          "Content-Type": "application/json",
        },
      }
    );

    const content = response.data.choices[0].message.content;
    res.json({ blogContent: content });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to generate blog" });
  }
};