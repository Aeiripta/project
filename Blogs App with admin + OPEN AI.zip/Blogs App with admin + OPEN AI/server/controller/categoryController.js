const User = require("../models/user");
const Category = require("../models/category");
const Blog = require("../models/blog");

// Add a new category
exports.addCategory = async (req, res) => {
  try {
    const { title } = req.body;

    if (!title) {
      console.log("Title is missing in the request body.");
      return res
        .status(400)
        .json({ success: false, error: "Title is required" });
    }

    const checkCat = await Category.findOne({ title });
    if (checkCat) {
      console.log("Category already exists:", title);
      return res
        .status(400)
        .json({ success: false, error: "Category already exists" });
    }

    const newCat = new Category({ title });
    await newCat.save();
    console.log("Category added successfully with title:", title);
    return res.status(200).json({ success: true, message: "Category added" });
  } catch (error) {
    console.log("Error in addCategory:", error);
    return res
      .status(500)
      .json({ success: false, error: "Internal server error" });
  }
};

// Get all categories
exports.getCategories = async (req, res) => {
  try {
    const categories = await Category.find();
    console.log(`Retrieved ${categories.length} categories.`);
    return res.status(200).json({ success: true, categories });
  } catch (error) {
    console.log("Error in getCategories:", error);
    return res
      .status(500)
      .json({ success: false, error: "Internal server error" });
  }
};

// Get blogs by a specific category ID
exports.getCategoriesById = async (req, res) => {
  try {
    const { id } = req.params;
    const category = await Category.findById(id).populate("blogs");

    if (!category) {
      console.log("No category found with id:", id);
      return res
        .status(400)
        .json({ success: false, error: "Category not found" });
    }

    console.log(
      "Category found with id:",
      id,
      "and blogs count:",
      category.blogs.length
    );
    return res.status(200).json({ success: true, blogs: category.blogs });
  } catch (error) {
    console.log("Error in getCategoriesById:", error);
    return res
      .status(500)
      .json({ success: false, error: "Internal server error" });
  }
};
