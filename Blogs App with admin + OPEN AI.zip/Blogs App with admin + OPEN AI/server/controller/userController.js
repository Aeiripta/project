const User = require("../models/user");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");

// Signup controller
exports.signupUser = async (req, res) => {
  try {
    const { username, email, password } = req.body;

    if (!username || !email || !password) {
      console.log("Missing required fields during signup.");
      return res
        .status(400)
        .json({ success: false, error: "All fields are required" });
    }

    // Check if username or email already exists
    const existingUser = await User.findOne({ $or: [{ username }, { email }] });
    if (existingUser) {
      console.log("Signup error: username or email already exists.");
      return res
        .status(400)
        .json({ success: false, error: "Username or email already exists" });
    }

    const hashedPass = await bcrypt.hash(password, 10);
    const newUser = new User({
      username,
      email,
      password: hashedPass,
    });

    await newUser.save();
    console.log("New user created:", username);
    return res.status(200).json({ success: true, message: "Account created" });
  } catch (error) {
    console.log("Error during signup:", error);
    return res
      .status(500)
      .json({ success: false, error: "Internal server error" });
  }
};

// Login controller
exports.loginUser = async (req, res) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      console.log("Login error: Missing email or password.");
      return res
        .status(400)
        .json({ success: false, error: "All fields are required" });
    }

    // Check if user exists by email
    const existingUser = await User.findOne({ email });
    if (!existingUser) {
      console.log("Login error: Invalid credentials.");
      return res
        .status(400)
        .json({ success: false, error: "Invalid credentials" });
    }

    const checkPass = await bcrypt.compare(password, existingUser.password);
    if (!checkPass) {
      console.log("Login error: Incorrect password.");
      return res
        .status(400)
        .json({ success: false, error: "Invalid credentials" });
    }

    const token = jwt.sign(
      {
        id: existingUser._id,
        email: existingUser.email,
      },
      process.env.JWT_SECRET,
      {
        expiresIn: "30d", // Token expires in 30 days
      }
    );

    res.cookie("blogsapptcm", token, {
      httpOnly: true,
      maxAge: 30 * 24 * 60 * 60 * 1000, // 30 days
      secure: true,
      sameSite: "None",
    });

    console.log("User logged in successfully:", existingUser.username);
    return res
      .status(200)
      .json({ success: true, message: "Login successfully" });
  } catch (error) {
    console.log("Error during login:", error);
    return res
      .status(500)
      .json({ success: false, error: "Internal server error" });
  }
};

// Check cookie existence
exports.checkCookie = (req, res) => {
  try {
    const token = req.cookies.blogsapptcm;
    console.log("Cookie check, token found:", !!token);
    if (token) {
      return res.status(200).json({ message: true });
    }
    return res.status(200).json({ message: false });
  } catch (error) {
    console.log("Error checking cookie:", error);
    return res.status(500).json({ error: "Internal server error" });
  }
};

// Logout controller
exports.logout = (req, res) => {
  res.clearCookie("blogsapptcm", {
    httpOnly: true,
    secure: true,
    sameSite: "None",
    path: "/",
  });
  console.log("User logged out successfully.");
  res.json({ message: "Logged out successfully" });
};

// Get profile data (omit password)
exports.getProfileData = (req, res) => {
  try {
    const { user } = req;
    if (!user) {
      console.log("No user found in the request to get profile data.");
      return res.status(400).json({ error: "No user data available" });
    }
    // Exclude sensitive password field
    const { password, ...safeUserData } = user._doc;
    console.log("Profile data retrieved for:", safeUserData.username);
    res.status(200).json({ data: safeUserData });
  } catch (error) {
    console.log("Error retrieving profile data:", error);
    return res.status(500).json({ error: "Internal server error" });
  }
};

// Change user password
exports.changeUserPassword = async (req, res) => {
  try {
    const { user } = req;
    const { password, newPass, confirmNewPass } = req.body;

    if (newPass !== confirmNewPass) {
      console.log("Password change error: New passwords do not match.");
      return res.status(400).json({
        error: "New password and confirm new password are not the same",
      });
    }

    // Compare current password
    const checkPass = await bcrypt.compare(password, user.password);
    if (!checkPass) {
      console.log("Password change error: Current password is incorrect.");
      return res
        .status(400)
        .json({ success: false, error: "Current password is not valid" });
    }

    // Hash the new password and update
    user.password = await bcrypt.hash(newPass, 10);
    await user.save();

    console.log("Password updated successfully for user:", user.username);
    res.status(200).json({ message: "Password updated successfully" });
  } catch (error) {
    console.log("Error while changing password:", error);
    return res.status(500).json({ error: "Internal server error" });
  }
};

// Change user avatar
exports.changeAvatar = async (req, res) => {
  try {
    const { user } = req;

    if (!req.file) {
      console.log("Change avatar error: No image file uploaded.");
      return res.status(400).json({ error: "No image file uploaded." });
    }

    user.avatar = req.file.path;
    await user.save();
    console.log("Avatar updated for user:", user.username);
    res.status(200).json({ message: "Avatar updated" });
  } catch (error) {
    console.log("Error updating avatar:", error);
    return res.status(500).json({ error: "Internal server error" });
  }
};

// Get favourite blogs of a user
exports.getFavouriteBlogsOfAUser = async (req, res) => {
  try {
    const { user } = req;
    const populatedUser = await User.findById(user._id).populate(
      "favouriteBlogs"
    );
    if (!populatedUser) {
      console.log("User not found when fetching favourite blogs.");
      return res.status(400).json({ error: "User not found" });
    }
    const favouriteBlogs = populatedUser.favouriteBlogs;
    console.log(
      `Fetched ${favouriteBlogs.length} favourite blogs for user:`,
      user.username
    );
    res.status(200).json({ success: true, favouriteBlogs });
  } catch (error) {
    console.log("Error fetching favourite blogs:", error);
    res.status(500).json({ error: "Internal server error" });
  }
};
