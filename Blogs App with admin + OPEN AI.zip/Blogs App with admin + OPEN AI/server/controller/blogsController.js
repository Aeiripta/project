const BLOG = require("../models/blog");
const USER = require("../models/user");
const jwt = require("jsonwebtoken");

// Fetch all blogs with populated 'category' and 'createdBy' details
exports.fetchAllBlogs = async (req, res) => {
  try {
    const blogs = await BLOG.find()
      .populate("category", "title")
      .populate("createdBy", "username email")
      .sort({ createdAt: -1 });
    console.log(`Fetched all blogs. Count: ${blogs.length}`);
    return res.status(200).json({ success: true, blogs });
  } catch (error) {
    console.log("Error in fetchAllBlogs:", error);
    return res.status(500).json({ error: "Internal server error" });
  }
};

// Fetch recent blogs (limit to 4) with populated details
exports.fetchRecentBlogs = async (req, res) => {
  try {
    const blogs = await BLOG.find()
      .populate("category", "title")
      .populate("createdBy", "username email")
      .sort({ createdAt: -1 })
      .limit(4);
    console.log(`Fetched recent blogs. Count: ${blogs.length}`);
    return res.status(200).json({ success: true, blogs });
  } catch (error) {
    console.log("Error in fetchRecentBlogs:", error);
    return res.status(500).json({ error: "Internal server error" });
  }
};

// Get blog description by ID along with the 'favourite' flag (if the current user has favorited it)
exports.getDescById = async (req, res) => {
  try {
    const token = req.cookies.blogsapptcm;
    let user = null;

    if (token) {
      try {
        const decoded = jwt.verify(token, process.env.JWT_SECRET);
        user = await USER.findById(decoded.id);
        console.log("User retrieved from token:", user?.username);
      } catch (err) {
        console.log("Error verifying token:", err.message);
      }
    }

    const { id } = req.params;
    const blog = await BLOG.findById(id)
      .populate("category", "title")
      .populate("createdBy", "username email");

    if (!blog) {
      console.log("No blog found with id:", id);
      return res.status(400).json({ error: "No blog found" });
    }

    let favourite = false;
    if (user && blog.favouriteBlogByUsers.includes(user._id)) {
      favourite = true;
    }

    console.log(`Blog ${id} retrieved. Favourite status is: ${favourite}`);
    return res.status(200).json({ success: true, blog, favourite });
  } catch (error) {
    console.log("Error in getDescById:", error);
    return res.status(500).json({ error: "Internal server error" });
  }
};

// Add blog to user's favourites
exports.addBlogsToFavourite = async (req, res) => {
  try {
    const { user } = req;
    const { id } = req.params;

    if (!user) {
      console.log("User not found in request context.");
      return res.status(401).json({ error: "Unauthorized access" });
    }

    const blog = await BLOG.findById(id);
    if (!blog) {
      console.log("Blog not found with id:", id);
      return res.status(400).json({ error: "No blog found" });
    }

    const existingUser = await USER.findById(user._id);

    // Add user to blog's favourite list if not added before
    if (!blog.favouriteBlogByUsers.includes(user._id)) {
      blog.favouriteBlogByUsers.push(user._id);
      console.log(`Added user ${user._id} to blog ${id} favourites`);
    } else {
      console.log(`User ${user._id} already favourited blog ${id}`);
    }

    // Add blog to user's favourite list if not already present
    if (!existingUser.favouriteBlogs.includes(id)) {
      existingUser.favouriteBlogs.push(id);
      console.log(`Added blog ${id} to user's favouriteBlogs`);
    }

    await blog.save();
    await existingUser.save();

    return res
      .status(200)
      .json({ success: true, message: "Blog added to favourites" });
  } catch (error) {
    console.log("Error in addBlogsToFavourite:", error);
    return res.status(500).json({ error: "Internal server error" });
  }
};

// Remove a blog from user's favourites
exports.removeBlogsFromFavourite = async (req, res) => {
  try {
    const { user } = req;
    const { id } = req.params;

    if (!user) {
      console.log("User not available for removing favourite.");
      return res.status(401).json({ error: "Unauthorized access" });
    }

    const blog = await BLOG.findById(id);
    if (!blog) {
      console.log("Blog not found with id:", id);
      return res.status(400).json({ error: "No blog found" });
    }

    const existingUser = await USER.findById(user._id);

    // Remove from user's favourites
    const userFavouriteIndex = existingUser.favouriteBlogs.indexOf(id);
    if (userFavouriteIndex !== -1) {
      existingUser.favouriteBlogs.splice(userFavouriteIndex, 1);
      console.log(`Removed blog ${id} from user's favouriteBlogs`);
    } else {
      console.log(`Blog ${id} not found in user's favourites`);
      return res
        .status(400)
        .json({ error: "Blog is not in user's favourites" });
    }

    // Remove user from blog's favourite list
    const blogFavouriteIndex = blog.favouriteBlogByUsers.indexOf(user._id);
    if (blogFavouriteIndex !== -1) {
      blog.favouriteBlogByUsers.splice(blogFavouriteIndex, 1);
      console.log(`Removed user ${user._id} from blog ${id} favourites`);
    }

    await blog.save();
    await existingUser.save();

    return res
      .status(200)
      .json({ success: true, message: "Blog removed from favourites" });
  } catch (error) {
    console.log("Error in removeBlogsFromFavourite:", error);
    return res.status(500).json({ error: "Internal server error" });
  }
};

// Edit a particular blog (update title and description)
exports.editBlog = async (req, res) => {
  try {
    const { id } = req.params;
    const { title, description } = req.body;

    console.log(
      `Editing blog ${id} with new title: ${title}, description: ${description}`
    );

    const updatedBlog = await BLOG.findByIdAndUpdate(
      id,
      { title, description },
      { new: true, runValidators: true }
    );
    if (!updatedBlog) {
      console.log("No blog found for editing with id:", id);
      return res.status(400).json({ error: "No blog found" });
    }
    console.log(`Blog ${id} updated successfully.`);
    return res
      .status(200)
      .json({ success: true, message: "Blog updated", blog: updatedBlog });
  } catch (error) {
    console.log("Error in editBlog:", error);
    return res.status(500).json({ error: "Internal server error" });
  }
};

// Delete a particular blog
exports.deleteBlog = async (req, res) => {
  try {
    const { id } = req.params;
    console.log(`Attempting deletion of blog ${id}`);

    const deletedBlog = await BLOG.findByIdAndDelete(id);
    if (!deletedBlog) {
      console.log("No blog found for deletion with id:", id);
      return res.status(400).json({ error: "No blog found" });
    }
    console.log(`Blog ${id} deleted successfully.`);
    return res
      .status(200)
      .json({ success: true, message: "Blog deleted successfully" });
  } catch (error) {
    console.log("Error in deleteBlog:", error);
    return res.status(500).json({ error: "Internal server error" });
  }
};
