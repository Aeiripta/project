const router = require("express").Router();
const BlogsController = require("../controller/blogsController");
const authMiddleware = require("../middlewares/authMiddleware");

// Fetch all blogs (public endpoint)
router.get("/fetchAllBlogs", BlogsController.fetchAllBlogs);

// Fetch recent blogs (public endpoint)
router.get("/fetchRecentBlogs", BlogsController.fetchRecentBlogs);

// Get blog details by blog ID (public endpoint)
router.get("/getDescById/:id", BlogsController.getDescById);

// Add a blog to the user's favourites (restricted to authenticated users with "user" role)
router.put(
  "/addBlogsToFavourite/:id",
  authMiddleware.verifyToken,
  authMiddleware.authorizeRole("user"),
  BlogsController.addBlogsToFavourite
);

// Remove a blog from the user's favourites (restricted to authenticated users with "user" role)
router.put(
  "/removeBlogsFromFavourite/:id",
  authMiddleware.verifyToken,
  authMiddleware.authorizeRole("user"),
  BlogsController.removeBlogsFromFavourite
);

// Edit a blog (restricted to authenticated admins)
router.put(
  "/editBlog/:id",
  authMiddleware.verifyToken,
  authMiddleware.authorizeRole("admin"),
  BlogsController.editBlog
);

// Delete a blog (restricted to authenticated admins)
// Note: This route currently uses PUT for deletion. You may consider using DELETE for semantic clarity.
router.put(
  "/deleteBlog/:id",
  authMiddleware.verifyToken,
  authMiddleware.authorizeRole("admin"),
  BlogsController.deleteBlog
);

module.exports = router;
