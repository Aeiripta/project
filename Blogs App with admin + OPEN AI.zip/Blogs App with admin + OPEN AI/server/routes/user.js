const router = require("express").Router();
const userController = require("../controller/userController");
const authMiddleware = require("../middlewares/authMiddleware");
const upload = require("../middlewares/ImageUpload");

// Sign-up API
router.post("/sign-up", userController.signupUser);

// Log-in API
router.post("/log-in", userController.loginUser);

// Check cookie existence
router.get("/check-cookie", userController.checkCookie);

// Logout API
router.post("/logout", userController.logout);

// Retrieve profile data (only accessible for users)
router.get(
  "/getProfileData",
  authMiddleware.verifyToken,
  authMiddleware.authorizeRole("user"),
  userController.getProfileData
);

// Change user password
router.put(
  "/changeUserPassword",
  authMiddleware.verifyToken,
  authMiddleware.authorizeRole("user"),
  userController.changeUserPassword
);

// Change user avatar (file upload for image)
router.put(
  "/changeAvatar",
  authMiddleware.verifyToken,
  authMiddleware.authorizeRole("user"),
  upload.single("image"),
  userController.changeAvatar
);

// Get favourite blogs of the logged-in user
router.get(
  "/getFavouriteBlogsOfAUser",
  authMiddleware.verifyToken,
  authMiddleware.authorizeRole("user"),
  userController.getFavouriteBlogsOfAUser
);

module.exports = router;
