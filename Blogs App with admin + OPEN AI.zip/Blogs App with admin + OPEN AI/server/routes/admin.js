const router = require("express").Router();
const adminController = require("../controller/adminController");
const authMiddleware = require("../middlewares/authMiddleware");
const upload = require("../middlewares/ImageUpload");

// Admin login
router.post("/adminLogin", adminController.adminLogin);

// Add blog (admin only) with image upload
router.post(
  "/addBlog",
  authMiddleware.verifyToken,
  authMiddleware.authorizeRole("admin"),
  upload.single("image"),
  adminController.addBlog
);

// Generate blog content (admin only)
router.post(
  "/generate-blog",
  authMiddleware.verifyToken,
  authMiddleware.authorizeRole("admin"),
  adminController.genearteBlog
);

// Generate image (admin only)
// Uncomment below when ready to use
// router.post(
//   "/generate-image",
//   authMiddleware.verifyToken,
//   authMiddleware.authorizeRole("admin"),
//   adminController.generateImage
// );

module.exports = router;
