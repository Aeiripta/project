const router = require("express").Router();
const categoryController = require("../controller/categoryController");
const authMiddleware = require("../middlewares/authMiddleware");

// Add a new category (accessible only to admin)
router.post(
  "/addCategory",
  authMiddleware.verifyToken,
  authMiddleware.authorizeRole("admin"),
  categoryController.addCategory
);

// Get all categories
router.get("/getCategory", categoryController.getCategories);

// Get blogs by category ID
router.get("/getCategoriesById/:id", categoryController.getCategoriesById);

module.exports = router;
