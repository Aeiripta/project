const express = require("express");
const app = express();
const cookieParser = require("cookie-parser");
const cors = require("cors");
require("dotenv").config();
require("./conn/conn");

// Import API route files
const userApi = require("./routes/user");
const adminApi = require("./routes/admin");
const catApi = require("./routes/category");
const blogsAPI = require("./routes/blogs");

// Set up CORS to allow requests from your frontend (adjust as needed)
app.use(
  cors({
    origin: ["http://localhost:5173"],
    credentials: true,
  })
);

// Middleware to parse JSON bodies and handle cookies
app.use(express.json());
app.use(cookieParser());

// (Optional) Default route for testing server availability
// app.get("/", (req, res) => {
//   res.send("Hello from server side");
// });

// Mount API routes under the /api/v1 prefix
app.use("/api/v1", userApi);
app.use("/api/v1", adminApi);
app.use("/api/v1", catApi);
app.use("/api/v1", blogsAPI);

// Start the server on the specified PORT from the environment variables
app.listen(process.env.PORT, () => {
  console.log(`Server Started at ${process.env.PORT}`);
});
